def customer_test(solution, answer):
    for key in solution.keys():
        lower_str1 = answer[key][0].strip().split( )
    for i in range(len(solution[key])):
        lower_str2 = solution[key][i].strip().split( )
        if lower_str1 == lower_str2:
            return 1.0
    return 0.0